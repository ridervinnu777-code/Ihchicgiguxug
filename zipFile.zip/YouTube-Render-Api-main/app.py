from flask import Flask, request, jsonify, send_file
import yt_dlp
import os
import uuid
import requests
import hashlib
import glob
import shutil

app = Flask(__name__)

# Base directory using /tmp (Render free plan uses ephemeral storage)
BASE_TEMP_DIR = "/tmp"

# Directory for storing temporary download files (will be cleared after each request)
TEMP_DOWNLOAD_DIR = os.path.join(BASE_TEMP_DIR, "download")
os.makedirs(TEMP_DOWNLOAD_DIR, exist_ok=True)

# Directory for storing cached audio files (persists until container restart)
CACHE_DIR = os.path.join(BASE_TEMP_DIR, "cache")
os.makedirs(CACHE_DIR, exist_ok=True)

# Directory for storing cached video files separately
CACHE_VIDEO_DIR = os.path.join(BASE_TEMP_DIR, "cache_video")
os.makedirs(CACHE_VIDEO_DIR, exist_ok=True)

# Maximum cache size in bytes (adjusted to 500MB for Render free plan)
MAX_CACHE_SIZE = 500 * 1024 * 1024  # 500MB

# Path to your cookies file (if needed)
COOKIES_FILE = "cookies.txt"  # Replace with your actual cookies file path if required

# Search API URL (used both for regular searches and Spotify link resolution)
SEARCH_API_URL = "https://odd-block-a945.tenopno.workers.dev/search?title="

# API key required to use the /download endpoint
API_KEY = "Artistbots"

# Optional: route yt-dlp requests through a proxy (helps when the host's own IP
# is rate-limited/blocked by YouTube, which is common on shared cloud hosts).
# Set this in your platform's environment variables, e.g.:
#   PROXY_URL=http://username:password@proxy-host:port
PROXY_URL = os.environ.get("PROXY_URL")


def get_cache_key(video_url):
    """Generate a cache key from the video URL."""
    return hashlib.md5(video_url.encode('utf-8')).hexdigest()


def get_directory_size(directory):
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(directory):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            if os.path.isfile(fp):
                total_size += os.path.getsize(fp)
    return total_size


def check_cache_size_and_cleanup():
    """Check combined cache size and remove all cache files if it exceeds the threshold."""
    total_size = get_directory_size(CACHE_DIR) + get_directory_size(CACHE_VIDEO_DIR)
    if total_size > MAX_CACHE_SIZE:
        for cache_dir in [CACHE_DIR, CACHE_VIDEO_DIR]:
            for file in os.listdir(cache_dir):
                file_path = os.path.join(cache_dir, file)
                try:
                    os.remove(file_path)
                except Exception as e:
                    print(f"Error deleting file {file_path}: {e}")


def normalize_video_url(url):
    """
    Accepts either a full YouTube URL or a bare video ID and
    returns a full YouTube watch URL. Spotify links are left as-is
    (resolved separately by resolve_spotify_link).
    """
    if not url:
        return url
    if url.startswith("http://") or url.startswith("https://"):
        return url
    # Treat as a bare video ID
    return f"https://www.youtube.com/watch?v={url}"


def _extract_and_download(video_url, base_opts):
    """
    Try downloading with a sequence of client/cookie strategies, since a single
    strategy can get blocked depending on the video and the server's IP:

    1. android + ios, WITHOUT cookies — works for the vast majority of public
       videos and yt-dlp silently skips these clients entirely if a cookiefile
       is set, so we must NOT pass cookies here.
    2. web + mweb, WITH cookies — needed for age-restricted/private videos,
       and as a fallback if step 1 gets blocked.

    Returns (info, downloaded_file_path) from whichever attempt succeeds.
    Raises the last error if every strategy fails.
    """
    strategies = [
        {'player_client': ['android', 'ios']},
        {'player_client': ['web', 'mweb'], 'cookiefile': COOKIES_FILE},
    ]

    last_error = None
    for strategy in strategies:
        opts = dict(base_opts)
        opts['extractor_args'] = {'youtube': {'player_client': strategy['player_client']}}
        if 'cookiefile' in strategy:
            opts['cookiefile'] = strategy['cookiefile']
        if PROXY_URL:
            opts['proxy'] = PROXY_URL

        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(video_url, download=True)
                downloaded_file = ydl.prepare_filename(info)
                return info, downloaded_file
        except Exception as e:
            last_error = e
            continue

    raise last_error


def download_audio(video_url):
    """
    Download audio from the given YouTube video URL with caching.
    If the audio file was previously downloaded, return the cached file.
    """
    cache_key = get_cache_key(video_url)
    cached_files = glob.glob(os.path.join(CACHE_DIR, f"{cache_key}.*"))
    if cached_files:
        return cached_files[0]

    unique_id = str(uuid.uuid4())
    output_template = os.path.join(TEMP_DOWNLOAD_DIR, f"{unique_id}.%(ext)s")
    base_opts = {
        # Fallback chain: try worst audio-only, then any worst stream, then whatever bestaudio/best is available.
        'format': 'worstaudio/worst/bestaudio/best',
        'outtmpl': output_template,
        'noplaylist': True,
        'quiet': True,
        'socket_timeout': 60,
        'max_memory': 450000,
    }

    try:
        info, downloaded_file = _extract_and_download(video_url, base_opts)
        ext = info.get("ext", "m4a")
        cached_file_path = os.path.join(CACHE_DIR, f"{cache_key}.{ext}")
        shutil.move(downloaded_file, cached_file_path)
        check_cache_size_and_cleanup()  # Check cache size after adding a new file
        return cached_file_path
    except Exception as e:
        raise Exception(f"Error downloading audio: {e}")


def download_video(video_url):
    """
    Download video (with audio) from the given YouTube video URL in 360p and
    worst audio quality with caching. If the video file was previously
    downloaded, return the cached file.
    """
    cache_key = hashlib.md5((video_url + "_video").encode('utf-8')).hexdigest()
    cached_files = glob.glob(os.path.join(CACHE_VIDEO_DIR, f"{cache_key}.*"))
    if cached_files:
        return cached_files[0]

    unique_id = str(uuid.uuid4())
    output_template = os.path.join(TEMP_DOWNLOAD_DIR, f"{unique_id}.%(ext)s")
    base_opts = {
        'format': 'bestvideo[height<=360]+worstaudio/worst/best[height<=360]/best',
        'outtmpl': output_template,
        'noplaylist': True,
        'quiet': True,
        'socket_timeout': 60,
        'max_memory': 300000,
        'merge_output_format': 'mp4',
    }

    try:
        info, downloaded_file = _extract_and_download(video_url, base_opts)
        cached_file_path = os.path.join(CACHE_VIDEO_DIR, f"{cache_key}.mp4")
        shutil.move(downloaded_file, cached_file_path)
        check_cache_size_and_cleanup()  # Check cache size after adding a new file
        return cached_file_path
    except Exception as e:
        raise Exception(f"Error downloading video: {e}")


def resolve_spotify_link(url):
    """
    If the URL is a Spotify link, use the search API to find the corresponding YouTube link.
    Otherwise, return the URL unchanged.
    """
    if "spotify.com" in url:
        response = requests.get(SEARCH_API_URL + url)
        if response.status_code != 200:
            raise Exception("Failed to fetch search results for the Spotify link")
        search_result = response.json()
        if not search_result or 'link' not in search_result:
            raise Exception("No YouTube link found for the given Spotify link")
        return search_result['link']
    return url


@app.route('/search', methods=['GET'])
def search_video():
    """
    Search for a YouTube video using the external API.
    """
    try:
        query = request.args.get('title')
        if not query:
            return jsonify({"error": "The 'title' parameter is required"}), 400

        response = requests.get(SEARCH_API_URL + query)
        if response.status_code != 200:
            return jsonify({"error": "Failed to fetch search results"}), 500

        search_result = response.json()
        if not search_result or 'link' not in search_result:
            return jsonify({"error": "No videos found for the given query"}), 404

        return jsonify({
            "title": search_result["title"],
            "url": search_result["link"],
            "duration": search_result.get("duration"),
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/download', methods=['GET'])
def download_endpoint():
    """
    Unified download endpoint.

    GET /download?url=VIDEO_ID&type=audio&api_key=KEY
    GET /download?url=VIDEO_ID&type=video&api_key=KEY

    - url: full YouTube/Spotify URL or a bare YouTube video ID
    - type: "audio" (default) or "video" (360p)
    - api_key: must match the configured API_KEY
    """
    try:
        # 1. Validate API key
        api_key = request.args.get('api_key')
        if api_key != API_KEY:
            return jsonify({"error": "Invalid or missing api_key"}), 401

        # 2. Resolve the video URL (by url param, or by title search)
        video_url = request.args.get('url')
        video_title = request.args.get('title')
        download_type = (request.args.get('type') or 'audio').lower()

        if download_type not in ('audio', 'video'):
            return jsonify({"error": "'type' must be either 'audio' or 'video'"}), 400

        if not video_url and not video_title:
            return jsonify({"error": "Either 'url' or 'title' parameter is required"}), 400

        if video_title and not video_url:
            response = requests.get(SEARCH_API_URL + video_title)
            if response.status_code != 200:
                return jsonify({"error": "Failed to fetch search results"}), 500
            search_result = response.json()
            if not search_result or 'link' not in search_result:
                return jsonify({"error": "No videos found for the given query"}), 404
            video_url = search_result['link']

        video_url = normalize_video_url(video_url)

        if video_url and "spotify.com" in video_url:
            video_url = resolve_spotify_link(video_url)

        # 3. Download based on requested type
        if download_type == 'video':
            cached_file_path = download_video(video_url)
        else:
            cached_file_path = download_audio(video_url)

        return send_file(
            cached_file_path,
            as_attachment=True,
            download_name=os.path.basename(cached_file_path)
        )
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        # Clean up temporary download files only (not the caches)
        for file in os.listdir(TEMP_DOWNLOAD_DIR):
            file_path = os.path.join(TEMP_DOWNLOAD_DIR, file)
            try:
                os.remove(file_path)
            except Exception as cleanup_error:
                print(f"Error deleting file {file_path}: {cleanup_error}")


@app.route('/')
def home():
    return """
    <h1>🎶 YouTube Downloader API</h1>
    <p>Use this API to search and download audio/video from YouTube videos.</p>
    <p><strong>Endpoints:</strong></p>
    <ul>
        <li><strong>/search</strong>: Search for a video by title. Query parameter: <code>?title=</code></li>
        <li><strong>/download</strong>: Download audio or video. Query parameters: <code>?url=</code> (video ID or full URL), <code>&type=audio|video</code>, <code>&api_key=</code></li>
    </ul>
    <p>Examples:</p>
    <ul>
        <li>Search: <code>/search?title=Your%20Favorite%20Song</code></li>
        <li>Download audio: <code>/download?url=dQw4w9WgXcQ&type=audio&api_key=Artistbots</code></li>
        <li>Download video (360p): <code>/download?url=dQw4w9WgXcQ&type=video&api_key=Artistbots</code></li>
        <li>Download by Title (audio): <code>/download?title=Your%20Favorite%20Song&type=audio&api_key=Artistbots</code></li>
        <li>Download from Spotify: <code>/download?url=https://open.spotify.com/track/...&type=audio&api_key=Artistbots</code></li>
    </ul>
    """


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
